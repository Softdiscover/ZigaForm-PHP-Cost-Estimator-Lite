<?php
if (!defined('BASEPATH')) {exit('No direct script access allowed');}
?>
<div class="rockertform-captions" style="display:none;">
    <input type="hidden" id="alert_header_msg_removing" value="<?php echo __('Removing','FRocket_admin'); ?>">
    <input type="hidden" id="alert_header_form_saved" value="<?php echo __('Form saved','FRocket_admin'); ?>">
    <input type="hidden" id="alert_header_msg_processing" value="<?php echo __('Processing','FRocket_admin'); ?>">
    <input type="hidden" id="alert_header_loading" value="<?php echo __('Loading','FRocket_admin'); ?>">
    <input type="hidden" id="alert_header_saving" value="<?php echo __('Saving','FRocket_admin'); ?>">
    
    
    
</div>
