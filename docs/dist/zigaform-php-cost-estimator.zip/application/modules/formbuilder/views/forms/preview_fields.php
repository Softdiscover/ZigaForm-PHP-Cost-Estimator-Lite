<?php
if (!defined('BASEPATH')) {exit('No direct script access allowed');}
?>
<div class="dev-preview-fields">
    <div id="uiform-clogic-graph-box">
       
  <p><?php echo __('Conditional Logic Graph','FRocket_admin'); ?></p>
  <ul class="uiform-tree">
    <li>
        <div class="sfdc-alert sfdc-alert-success" role="alert">
           <b><?php echo __('Field Name','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">field_1</div><br>
           <b><?php echo __('Type','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">Textbox</div>
        </div>
      <ul>
        <li><div class="sfdc-alert sfdc-alert-info" role="alert">
           <b><?php echo __('Field Name','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">field_1</div><br>
           <b><?php echo __('Type','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">Textbox</div>
            </div></li>
        <li><div class="sfdc-alert sfdc-alert-info" role="alert">
           <b><?php echo __('Field Name','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">field_1</div><br>
           <b><?php echo __('Type','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">Textbox</div>
            </div></li>
        <li><div class="sfdc-alert sfdc-alert-info" role="alert">
           <b><?php echo __('Field Name','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">field_1</div><br>
           <b><?php echo __('Type','FRocket_admin'); ?>:</b> <div class="uifm-clogic-graph-text1">Textbox</div>
            </div></li>
      </ul>
    </li>
   
  </ul>
</div>
    
    
    
</div>
   
